
/**
 *
 * @author thalita
 */
public class CursoA {
    //Atributos
    private int CodCurso;
    private String NomeCurso;
    private String TipoCurso;
    private int CargaHoraria;
    private int CodInstituto;
     
 
    //Getters e Setters
    public int getCodCurso() {
        return CodCurso;
    }

    public void setCodCurso(int CodCurso) {
        this.CodCurso = CodCurso;
    }

    public String getNomeCurso() {
        return NomeCurso;
    }

    public void setNomeCurso(String NomeCurso) {
        this.NomeCurso = NomeCurso;
    }

    public String getTipoCurso() {
        return TipoCurso;
    }

    public void setTipoCurso(String TipoCurso) {
        this.TipoCurso = TipoCurso;
    }

    public int getCargaHoraria() {
        return CargaHoraria;
    }

    public void setCargaHoraria(int CargaHoraria) {
        this.CargaHoraria = CargaHoraria;
    }

    public int getCodInstituto() {
        return CodInstituto;
    }

    public void setCodInstituto(int CodInstituto) {
        this.CodInstituto = CodInstituto;
    }

}
